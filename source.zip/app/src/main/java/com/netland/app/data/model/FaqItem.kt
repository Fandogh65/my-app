package com.netland.app.data.model

data class FaqItem(
    val id: Int,
    val question: String,
    val answer: String,
    val category: String = "عمومی",
    var isExpanded: Boolean = false
)
