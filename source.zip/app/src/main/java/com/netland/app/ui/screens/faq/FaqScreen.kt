package com.netland.app.ui.screens.faq

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.netland.app.data.model.FaqItem
import com.netland.app.ui.theme.NetLandPrimary
import com.netland.app.ui.theme.NetLandTextSecondary

@Composable
fun FaqScreen(navController: NavController) {
    val faqList = remember {
        listOf(
            FaqItem(1, "آیا دریافت اینترنت و شارژ واقعاً رایگان است؟", "بله، تمامی جشنواره‌ها و طرح‌های معرفی‌شده در نت‌لند مستقیماً توسط اپراتورها و شرکت‌های معتبر برگزار شده و شرکت در آن‌ها رایگان است."),
            FaqItem(2, "چگونه کدهای هدیه و جوایز را دریافت کنم؟", "کافیست وارد جشنواره مورد نظر شوید، کد هدیه یا معرف را کپی کنید و طبق راهنمای داخل صفحه اقدام نمایید."),
            FaqItem(3, "آیا هر کاربر چند بار می‌تواند در جشنواره شرکت کند؟", "شرایط هر جشنواره متفاوت است و جزئیات دقیق آن در بخش توضیحات همان جشنواره ذکر شده است."),
            FaqItem(4, "چگونه می‌توانم با پشتیبانی در ارتباط باشم؟", "از طریق بخش پشتیبانی آنلاین در منوی برنامه می‌توانید در ۲۴ ساعت شبانه‌روز با کارشناسان ما گفتگو کنید.")
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Text(
            text = "سوالات متداول (FAQ)",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(20.dp),
            color = MaterialTheme.colorScheme.onBackground
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 6.dp)
        ) {
            items(faqList) { item ->
                var expanded by remember { mutableStateOf(item.id == 1) }

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp)
                        .clickable { expanded = !expanded },
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = item.question,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                modifier = Modifier.weight(1f)
                            )
                            Icon(
                                imageVector = if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                contentDescription = null,
                                tint = NetLandPrimary
                            )
                        }

                        AnimatedVisibility(visible = expanded) {
                            Column {
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = item.answer,
                                    fontSize = 13.sp,
                                    color = NetLandTextSecondary,
                                    lineHeight = 22.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
