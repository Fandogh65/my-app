package com.netland.app.notification

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.netland.app.MainActivity
import com.netland.app.R
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object NotificationHelper {

    const val CHANNEL_ID = "netland_alerts"
    const val CHANNEL_NAME = "اعلان‌ها، جشنواره‌ها و پشتیبانی نت‌لند"
    private const val PREFS_NAME = "netland_notification_prefs"
    private const val KEY_FIRST_LAUNCH = "first_launch"
    private const val KEY_KNOWN_FESTIVALS = "known_festivals"
    private const val KEY_KNOWN_NOTIFICATIONS = "known_notifications"
    private const val KEY_KNOWN_SUPPORT_REPLIES = "known_support_replies"
    private const val KEY_USER_ID = "user_id_cache"

    // تابع حذف ایموجی‌ها از متن
    private fun removeEmojis(text: String): String {
        return text.replace(
            Regex("[\\p{So}\\p{Cn}\\x{1F600}-\\x{1F64F}\\x{1F300}-\\x{1F5FF}\\x{1F680}-\\x{1F6FF}\\x{1F1E0}-\\x{1F1FF}\\x{2600}-\\x{26FF}\\x{2700}-\\x{27BF}\\x{FE00}-\\x{FE0F}\\x{1F900}-\\x{1F9FF}]"),
            ""
        ).trim()
    }

    fun createNotificationChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "اطلاع‌رسانی فوری در مورد جشنواره‌ها، کدهای هدیه، اعلان‌ها و پاسخ پشتیبانی نت‌لند"
                enableLights(true)
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 300, 150, 300)
            }
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    fun saveUserId(context: Context, userId: String) {
        if (userId.isNotBlank()) {
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putString(KEY_USER_ID, userId)
                .apply()
        }
    }

    fun getSavedUserId(context: Context): String? {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_USER_ID, null)
    }

    fun showNotification(
        context: Context,
        id: Int,
        title: String,
        message: String,
        targetUrl: String? = null
    ) {
        createNotificationChannel(context)

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            if (!targetUrl.isNullOrEmpty()) {
                putExtra("target_url", targetUrl)
            }
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            id,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_netland)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .setColor(0xFF6D35E8.toInt())

        val notificationManager = NotificationManagerCompat.from(context)
        try {
            notificationManager.notify(id, builder.build())
        } catch (_: SecurityException) {
            // Permission not granted
        }
    }

    /**
     * بررسی بک‌اند و ارسال نوتیفیکیشن فوری برای:
     * ۱. جشنواره‌های جدید (Festivals)
     * ۲. اعلان‌های عمومی جدید (Notifications)
     * ۳. پاسخ‌های پشتیبانی ادمین به پیام‌های کاربر (Support Replies)
     */
    fun checkBackendUpdates(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val isFirstLaunch = prefs.getBoolean(KEY_FIRST_LAUNCH, true)
        val knownFestivals = prefs.getStringSet(KEY_KNOWN_FESTIVALS, emptySet())?.toMutableSet() ?: mutableSetOf()
        val knownNotifications = prefs.getStringSet(KEY_KNOWN_NOTIFICATIONS, emptySet())?.toMutableSet() ?: mutableSetOf()
        val knownSupportReplies = prefs.getStringSet(KEY_KNOWN_SUPPORT_REPLIES, emptySet())?.toMutableSet() ?: mutableSetOf()

        // 1. بررسی جشنواره‌های جدید از کلادفلر ورکر
        try {
            val festUrl = URL("https://net-land-api.zz4591757.workers.dev/api/festivals")
            val conn = festUrl.openConnection() as HttpURLConnection
            conn.connectTimeout = 7000
            conn.readTimeout = 7000
            if (conn.responseCode == 200) {
                val response = conn.inputStream.bufferedReader().use { it.readText() }
                val json = JSONObject(response)
                val documents = json.optJSONArray("documents")
                if (documents != null) {
                    val currentFestivalIds = mutableSetOf<String>()
                    for (i in 0 until documents.length()) {
                        val doc = documents.getJSONObject(i)
                        val name = doc.optString("name", "")
                        val id = name.split("/").lastOrNull() ?: continue
                        currentFestivalIds.add(id)

                        // اگر جشنواره جدید باشد و بار اول نباشد، نوتیفیکیشن ارسال می‌شود
                        if (!isFirstLaunch && !knownFestivals.contains(id)) {
                            showNotification(
                                context = context,
                                id = ("fest_$id").hashCode(),
                                title = "جشنواره جدید اضافه شد",
                                message = "برای دیدن جشنواره کلیک کنید.",
                                targetUrl = "file:///android_asset/netland/festival-detail.html?id=$id"
                            )
                        }
                    }
                    prefs.edit().putStringSet(KEY_KNOWN_FESTIVALS, currentFestivalIds).apply()
                }
            }
        } catch (_: Exception) {
        }

        // 2. بررسی اعلان‌های جدید از کلادفلر ورکر
        try {
            val notifUrl = URL("https://net-land-api.zz4591757.workers.dev/api/notifications")
            val conn = notifUrl.openConnection() as HttpURLConnection
            conn.connectTimeout = 7000
            conn.readTimeout = 7000
            if (conn.responseCode == 200) {
                val response = conn.inputStream.bufferedReader().use { it.readText() }
                val json = JSONObject(response)
                val notifications = json.optJSONArray("notifications")
                if (notifications != null) {
                    val currentNotifIds = mutableSetOf<String>()
                    for (i in 0 until notifications.length()) {
                        val n = notifications.getJSONObject(i)
                        val id = n.optString("id", "")
                        if (id.isEmpty()) continue
                        currentNotifIds.add(id)

                        val rawTitle = n.optString("title", "اعلان جدید")
                        val rawMessage = n.optString("message", "")

                        // حذف هرگونه ایموجی و دریافت مستقیم از اطلاعات اعلان
                        val cleanTitle = removeEmojis(rawTitle)
                        val cleanMessage = removeEmojis(rawMessage)

                        // اگر اعلان جدید باشد و بار اول نباشد، نوتیفیکیشن ارسال می‌شود
                        if (!isFirstLaunch && !knownNotifications.contains(id)) {
                            showNotification(
                                context = context,
                                id = ("notif_$id").hashCode(),
                                title = cleanTitle,
                                message = cleanMessage,
                                targetUrl = "file:///android_asset/netland/notifications.html"
                            )
                        }
                    }
                    prefs.edit().putStringSet(KEY_KNOWN_NOTIFICATIONS, currentNotifIds).apply()
                }
            }
        } catch (_: Exception) {
        }

        // 3. بررسی پاسخ‌های پیام‌های پشتیبانی (Support Messages)
        try {
            val savedUserId = prefs.getString(KEY_USER_ID, null)
            var responseText: String? = null

            // اول از ورکر و در صورت خطای احراز هویت از Firestore REST استفاده می‌کنیم
            try {
                val supportUrl = URL("https://net-land-api.zz4591757.workers.dev/api/support-messages")
                val conn = supportUrl.openConnection() as HttpURLConnection
                conn.connectTimeout = 5000
                conn.readTimeout = 5000
                if (conn.responseCode == 200) {
                    responseText = conn.inputStream.bufferedReader().use { it.readText() }
                }
            } catch (_: Exception) {}

            if (responseText == null || responseText.contains("\"error\"")) {
                try {
                    val firestoreUrl = URL("https://firestore.googleapis.com/v1/projects/net-land-web/databases/(default)/documents/support_messages?pageSize=100")
                    val fsConn = firestoreUrl.openConnection() as HttpURLConnection
                    fsConn.connectTimeout = 7000
                    fsConn.readTimeout = 7000
                    if (fsConn.responseCode == 200) {
                        responseText = fsConn.inputStream.bufferedReader().use { it.readText() }
                    }
                } catch (_: Exception) {}
            }

            if (!responseText.isNullOrEmpty()) {
                val json = JSONObject(responseText)
                val documents = json.optJSONArray("documents")
                if (documents != null) {
                    val currentReplyIds = mutableSetOf<String>()
                    for (i in 0 until documents.length()) {
                        val doc = documents.getJSONObject(i)
                        val docName = doc.optString("name", "")
                        val docId = docName.split("/").lastOrNull() ?: continue
                        val fields = doc.optJSONObject("fields") ?: JSONObject()

                        val msgUserId = fields.optJSONObject("userId")?.optString("stringValue", "") ?: ""
                        val isAdmin = fields.optJSONObject("isAdmin")?.optBoolean("booleanValue", false) ?: false
                        val repliedBy = fields.optJSONObject("repliedBy")?.optString("stringValue", "") ?: ""
                        val reply = fields.optJSONObject("reply")?.optString("stringValue", "") ?: ""
                        val replyText = fields.optJSONObject("replyText")?.optString("stringValue", "") ?: ""
                        val messageText = fields.optJSONObject("message")?.optString("stringValue", "") ?: ""

                        // بررسی اینکه آیا این پیام پاسخ ادمین به کاربر است
                        val isUserMatch = savedUserId == null || msgUserId.isEmpty() || msgUserId == savedUserId
                        val hasAdminReply = isAdmin || repliedBy == "admin" || reply.isNotEmpty() || replyText.isNotEmpty()

                        if (hasAdminReply && isUserMatch) {
                            val replyContent = when {
                                reply.isNotEmpty() -> reply
                                replyText.isNotEmpty() -> replyText
                                else -> messageText
                            }
                            val replyUniqueKey = "${docId}_${replyContent.hashCode()}"
                            currentReplyIds.add(replyUniqueKey)

                            if (!isFirstLaunch && !knownSupportReplies.contains(replyUniqueKey)) {
                                showNotification(
                                    context = context,
                                    id = ("support_$replyUniqueKey").hashCode(),
                                    title = "پیام جدید پشتیبانی",
                                    message = "پیام پشتیبانی",
                                    targetUrl = "file:///android_asset/netland/support.html"
                                )
                            }
                        }
                    }
                    prefs.edit().putStringSet(KEY_KNOWN_SUPPORT_REPLIES, currentReplyIds).apply()
                }
            }
        } catch (_: Exception) {
        }

        if (isFirstLaunch) {
            prefs.edit().putBoolean(KEY_FIRST_LAUNCH, false).apply()
        }
    }
}
