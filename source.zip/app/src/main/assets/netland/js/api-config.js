// ============================================
// api-config.js - اتصال به Cloudflare Worker
// ============================================

const API_BASE_URL = 'https://net-land-api.zz4591757.workers.dev';

// کلید ذخیره‌سازی کش جشنواره‌ها در localStorage
const FESTIVALS_CACHE_KEY = 'netland_festivals_offline_cache';

function getCachedFestivals() {
  try {
    const raw = localStorage.getItem(FESTIVALS_CACHE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch (e) {
    console.warn('⚠️ خطا در خواندن کش جشنواره‌ها:', e);
    return [];
  }
}

function saveCachedFestivals(festivals) {
  if (Array.isArray(festivals) && festivals.length > 0) {
    try {
      localStorage.setItem(FESTIVALS_CACHE_KEY, JSON.stringify(festivals));
      console.log('💾 جشنواره‌ها در حافظه کش محلی ذخیره شدند:', festivals.length);
    } catch (e) {
      console.warn('⚠️ خطا در ذخیره کش جشنواره‌ها:', e);
    }
  }
}

async function getFestivals() {
  try {
    // تلاش برای دریافت مستقیم از سرور کلادفلر
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 7000);
    const response = await fetch(`${API_BASE_URL}/api/festivals`, {
      signal: controller.signal
    });
    clearTimeout(timeoutId);

    if (response && response.ok) {
      const data = await response.json();
      
      if (data && data.documents && Array.isArray(data.documents)) {
        const docs = data.documents.map(doc => {
          const fields = doc.fields || {};
          return {
            id: doc.name ? doc.name.split('/').pop() : '',
            title: fields.title?.stringValue || 'بدون عنوان',
            badge: fields.badge?.stringValue || 'ویژه',
            description: fields.description?.stringValue || '',
            type: fields.type?.stringValue || 'charge',
            icon: fields.icon?.stringValue || 'purple',
            status: fields.status?.stringValue || 'active',
            meta: fields.meta?.stringValue || fields.endDate?.stringValue || '',
            information: fields.information?.stringValue || '',
            link: fields.link?.stringValue || '#',
            referralCode: fields.referralCode?.stringValue || '',
            image: fields.image?.stringValue || '',
            durationType: fields.durationType?.stringValue || '',
            createdAt: fields.createdAt?.timestampValue || null,
            endDate: fields.endDate?.stringValue || ''
          };
        });

        if (docs.length > 0) {
          saveCachedFestivals(docs);
        }

        if (typeof Android !== 'undefined' && Android.checkUpdates) {
          try { Android.checkUpdates(); } catch (e) {}
        }
        return docs;
      }
    }
    
    // اگر پاسخ سرور معتبر نبود یا خطای اچ‌تی‌تی‌پی داشت، از آخرین کش استفاده می‌شود
    console.warn('⚠️ پاسخ نامعتبر از سرور، استفاده از کش ذخیره شده');
    const cached = getCachedFestivals();
    if (cached.length > 0) return cached;
    return [];

  } catch (error) {
    console.warn('⚠️ خطا یا عدم دسترسی به سرور، بازیابی جشنواره‌ها از آخرین کش:', error);
    const cached = getCachedFestivals();
    if (cached.length > 0) {
      console.log('✅ جشنواره‌ها با موفقیت از آخرین کش بارگذاری شدند:', cached.length);
      return cached;
    }
    return [];
  }
}

// ============================================
// دریافت جزئیات یک جشنواره با ID (برای festival-detail.html)
// ============================================
async function getFestivalById(id) {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 7000);
    const response = await fetch(`${API_BASE_URL}/api/festival/${id}`, {
      signal: controller.signal
    });
    clearTimeout(timeoutId);

    if (response && response.ok) {
      const data = await response.json();
      if (data && data.fields) {
        const fields = data.fields;
        return {
          id: data.name ? data.name.split('/').pop() : id,
          title: fields.title?.stringValue || 'بدون عنوان',
          badge: fields.badge?.stringValue || 'ویژه',
          description: fields.description?.stringValue || '',
          type: fields.type?.stringValue || 'charge',
          icon: fields.icon?.stringValue || 'purple',
          status: fields.status?.stringValue || 'active',
          meta: fields.meta?.stringValue || fields.endDate?.stringValue || '',
          information: fields.information?.stringValue || '',
          link: fields.link?.stringValue || '#',
          referralCode: fields.referralCode?.stringValue || '',
          image: fields.image?.stringValue || '',
          durationType: fields.durationType?.stringValue || '',
          endDate: fields.endDate?.stringValue || '',
          joinUrl: fields.joinUrl?.stringValue || fields.link?.stringValue || '',
          createdAt: fields.createdAt?.timestampValue || null
        };
      }
    }
    
    // در صورت قطعی ارتباط با سرور، جشنواره از کش محلی پیدا می‌شود
    const cached = getCachedFestivals();
    const found = cached.find(f => f.id === id);
    if (found) {
      console.log('✅ جزئیات جشنواره از کش محلی بازیابی شد:', found.title);
      return found;
    }
    return null;

  } catch (error) {
    console.warn('⚠️ خطا در دریافت جزئیات جشنواره از سرور، جستجو در کش محلی:', error);
    const cached = getCachedFestivals();
    const found = cached.find(f => f.id === id);
    if (found) {
      console.log('✅ جزئیات جشنواره از کش محلی بازیابی شد:', found.title);
      return found;
    }
    return null;
  }
}

// ============================================
// پشتیبانی (Support) - برای support.html و admin-support.html
// ============================================

async function getSupportMessages() {
  try {
    // تلاش مستقیم از طریق ورکر یا ریست API فایراستور
    let data = null;
    try {
      const response = await fetch(`${API_BASE_URL}/api/support-messages`);
      if (response.ok) {
        data = await response.json();
      }
    } catch (_) {}

    // اگر ورکر خطای دسترسی یا ۴۰۳ داد، مستقیماً از Firestore REST دریافت می‌کنیم
    if (!data || !data.documents) {
      try {
        const firestoreResp = await fetch(
          'https://firestore.googleapis.com/v1/projects/net-land-web/databases/(default)/documents/support_messages?pageSize=100'
        );
        if (firestoreResp.ok) {
          data = await firestoreResp.json();
        }
      } catch (e) {
        console.warn('⚠️ خطا در دریافت از Firestore REST:', e);
      }
    }
    
    if (data && data.documents && Array.isArray(data.documents)) {
      return data.documents.map(doc => {
        const fields = doc.fields || {};
        return {
          id: doc.name ? doc.name.split('/').pop() : '',
          userId: fields.userId?.stringValue || '',
          username: fields.username?.stringValue || '',
          message: fields.message?.stringValue || '',
          isAdmin: fields.isAdmin?.booleanValue || false,
          reply: fields.reply?.stringValue || null,
          replyText: fields.replyText?.stringValue || null,
          repliedBy: fields.repliedBy?.stringValue || null,
          repliedAt: fields.repliedAt?.timestampValue || null,
          createdAt: fields.createdAt?.timestampValue || null
        };
      });
    }
    return [];
  } catch (error) {
    console.warn('❌ خطا در دریافت پیام‌ها:', error);
    return [];
  }
}

// ============================================
// ارسال پیام پشتیبانی (با پشتیبانی از isAdmin)
// ============================================
async function sendSupportMessage(userId, username, message, isAdmin = false) {
  try {
    const payload = {
      userId,
      username: username || 'کاربر مهمان',
      message,
      isAdmin: isAdmin || false,
      repliedBy: isAdmin ? 'admin' : null,
      sender: isAdmin ? 'admin' : 'user',
      senderType: isAdmin ? 'admin' : 'user',
      role: isAdmin ? 'admin' : 'user'
    };
    
    const response = await fetch(`${API_BASE_URL}/api/support`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(payload)
    });
    if (!response.ok) {
      console.warn('⚠️ سرور پاسخ غیر ۲۰۰ داد:', response.status);
    }
    const resData = await response.json();
    return resData;
  } catch (error) {
    console.warn('❌ خطا در ارسال پیام به سرور:', error);
    return { success: false, error: error.message };
  }
}

// ============================================
// دریافت پیام‌های یک کاربر با پاسخ‌های ادمین
// ============================================
async function getUserSupportMessages(userId) {
  try {
    const allMessages = await getSupportMessages();
    if (!Array.isArray(allMessages)) return [];
    
    const userMessages = allMessages.filter(msg => {
      if (!msg) return false;
      if (msg.userId === userId) return true;
      if (msg.isAdmin === true && msg.userId === userId) return true;
      if (msg.reply && msg.userId === userId) return true;
      return false;
    });
    
    return userMessages;
  } catch (error) {
    console.warn('❌ خطا در دریافت پیام‌های کاربر:', error);
    return [];
  }
}

// ============================================
// دریافت همه پیام‌های پشتیبانی (برای پنل ادمین)
// ============================================
async function getAllSupportMessages() {
  try {
    return await getSupportMessages();
  } catch (error) {
    console.error('❌ خطا در getAllSupportMessages:', error);
    return [];
  }
}

// ============================================
// ارسال پاسخ ادمین به یک پیام خاص
// ============================================
async function sendAdminReply(userId, userName, message) {
  try {
    const response = await fetch(`${API_BASE_URL}/api/support`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        userId: userId,
        username: userName || 'ادمین',
        message: message,
        isAdmin: true,
        repliedBy: 'admin',
        sender: 'admin',
        senderType: 'admin',
        role: 'admin'
      })
    });

    if (!response.ok) {
      const result = await response.json();
      throw new Error(result.error || 'خطا در ارسال پاسخ');
    }

    return await response.json();
  } catch (error) {
    console.error('❌ خطا در sendAdminReply:', error);
    throw error;
  }
}

// ============================================
// توابع کمکی
// ============================================

function getUserId() {
  let id = localStorage.getItem('netland_user_id');
  if (!id) {
    id = 'user_' + Date.now() + '_' + Math.random().toString(36).substr(2, 6);
    localStorage.setItem('netland_user_id', id);
  }
  return id;
}

function getUserName() {
  let name = localStorage.getItem('netland_username');
  if (!name) {
    name = 'کاربر مهمان';
  }
  return name;
}