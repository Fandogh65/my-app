package com.netland.app.data.model

import com.google.gson.annotations.SerializedName

data class Festival(
    val id: String = "",
    val title: String = "",
    val badge: String = "ویژه",
    val description: String = "",
    val type: String = "charge", // charge, internet, combo, special
    val icon: String = "purple",
    val status: String = "active",
    val meta: String = "",
    val information: String = "",
    val link: String = "#",
    val referralCode: String = "",
    val image: String = "",
    val durationType: String = "",
    val endDate: String = "",
    val joinUrl: String = "",
    val createdAt: String? = null,
    val isFavorite: Boolean = false
)

data class CloudflareResponse(
    @SerializedName("documents")
    val documents: List<FirestoreDocument>? = null
)

data class FirestoreDocument(
    @SerializedName("name")
    val name: String? = null,
    @SerializedName("fields")
    val fields: Map<String, FirestoreValue>? = null
)

data class FirestoreValue(
    @SerializedName("stringValue")
    val stringValue: String? = null,
    @SerializedName("booleanValue")
    val booleanValue: Boolean? = null,
    @SerializedName("timestampValue")
    val timestampValue: String? = null
)
