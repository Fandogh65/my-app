package com.netland.app.ui.screens.favorites

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.netland.app.data.model.Festival
import com.netland.app.data.repository.FestivalRepository
import com.netland.app.ui.navigation.Screen
import com.netland.app.ui.screens.home.FestivalCardItem
import com.netland.app.ui.theme.NetLandPrimary

@Composable
fun FavoritesScreen(navController: NavController) {
    val repository = remember { FestivalRepository() }
    var allFestivals by remember { mutableStateOf<List<Festival>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        allFestivals = repository.getFestivals()
        isLoading = false
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Text(
            text = "جشنواره‌های برگزیده و نشان‌شده",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(20.dp),
            color = MaterialTheme.colorScheme.onBackground
        )

        if (isLoading) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = NetLandPrimary)
            }
        } else if (allFestivals.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("موردی ذخیره نشده است.", color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 20.dp)
            ) {
                items(allFestivals.take(5)) { festival ->
                    FestivalCardItem(
                        festival = festival,
                        onClick = {
                            navController.navigate(Screen.FestivalDetail.createRoute(festival.id))
                        }
                    )
                }
            }
        }
    }
}
