# Add project specific ProGuard rules here.
# You can control the set of applied configuration files using the
# proguardFiles setting in build.gradle.

# Keep annotations and WebView JavascriptInterface methods
-keepattributes JavascriptInterface
-keepattributes *Annotation*
-keepattributes SourceFile,LineNumberTable

-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

-keep class com.netland.app.MainActivity$WebAppInterface {
    public *;
}

-keep class com.netland.app.notification.** { *; }

-dontwarn org.json.**
-dontwarn android.webkit.**
-keep class com.netland.app.data.model.** { *; }
-keepclassmembers class com.netland.app.data.model.** { *; }
