package com.netland.app.data.repository

import com.netland.app.data.model.Festival
import com.netland.app.data.remote.NetLandApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class FestivalRepository(
    private val api: NetLandApi = NetLandApi.create()
) {
    suspend fun getFestivals(): List<Festival> = withContext(Dispatchers.IO) {
        try {
            val response = api.getFestivals()
            response.documents?.map { doc ->
                val f = doc.fields ?: emptyMap()
                val id = doc.name?.split("/")?.lastOrNull() ?: ""
                Festival(
                    id = id,
                    title = f["title"]?.stringValue ?: "جشنواره نت‌لند",
                    badge = f["badge"]?.stringValue ?: "ویژه",
                    description = f["description"]?.stringValue ?: "",
                    type = f["type"]?.stringValue ?: "charge",
                    icon = f["icon"]?.stringValue ?: "purple",
                    status = f["status"]?.stringValue ?: "active",
                    meta = f["meta"]?.stringValue ?: f["endDate"]?.stringValue ?: "مهلت محدود",
                    information = f["information"]?.stringValue ?: "",
                    link = f["link"]?.stringValue ?: "#",
                    referralCode = f["referralCode"]?.stringValue ?: "",
                    image = f["image"]?.stringValue ?: "",
                    durationType = f["durationType"]?.stringValue ?: "",
                    endDate = f["endDate"]?.stringValue ?: "",
                    joinUrl = f["joinUrl"]?.stringValue ?: f["link"]?.stringValue ?: "",
                    createdAt = f["createdAt"]?.timestampValue
                )
            } ?: emptyList()
        } catch (e: Exception) {
            e.printStackTrace()
            emptyList()
        }
    }
}
