package com.netland.app.data.model

data class SupportMessage(
    val id: String = "",
    val userId: String = "",
    val username: String = "کاربر",
    val message: String = "",
    val isAdmin: Boolean = false,
    val repliedBy: String? = null,
    val repliedAt: String? = null,
    val createdAt: String? = null
)

data class SendSupportRequest(
    val userId: String,
    val username: String,
    val message: String,
    val isAdmin: Boolean = false,
    val sender: String = "user",
    val senderType: String = "user",
    val role: String = "user"
)
