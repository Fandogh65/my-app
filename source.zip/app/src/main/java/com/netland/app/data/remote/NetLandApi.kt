package com.netland.app.data.remote

import com.netland.app.data.model.CloudflareResponse
import com.netland.app.data.model.FirestoreDocument
import com.netland.app.data.model.SendSupportRequest
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path
import java.util.concurrent.TimeUnit

interface NetLandApi {
    @GET("api/festivals")
    suspend fun getFestivals(): CloudflareResponse

    @GET("api/festival/{id}")
    suspend fun getFestivalById(@Path("id") id: String): FirestoreDocument

    @GET("api/support-messages")
    suspend fun getSupportMessages(): CloudflareResponse

    @POST("api/support")
    suspend fun sendSupportMessage(@Body request: SendSupportRequest): Any

    companion object {
        private const val BASE_URL = "https://net-land-api.zz4591757.workers.dev/"

        fun create(): NetLandApi {
            val logging = HttpLoggingInterceptor().apply {
                level = HttpLoggingInterceptor.Level.BODY
            }
            val client = OkHttpClient.Builder()
                .addInterceptor(logging)
                .connectTimeout(15, TimeUnit.SECONDS)
                .readTimeout(15, TimeUnit.SECONDS)
                .build()

            return Retrofit.Builder()
                .baseUrl(BASE_URL)
                .client(client)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
                .create(NetLandApi::class.java)
        }
    }
}
