package com.netland.app.ui.theme

import androidx.compose.ui.graphics.Color

val NetLandPrimary = Color(0xFF6D35E8)
val NetLandPrimary2 = Color(0xFF8255F3)
val NetLandPrimaryLight = Color(0xFFF0EBFF)
val NetLandBlue = Color(0xFF4F7CFF)
val NetLandGreen = Color(0xFF25B96F)
val NetLandGreenLight = Color(0xFFE9F9F0)
val NetLandOrange = Color(0xFFF3A623)
val NetLandOrangeLight = Color(0xFFFFF3DC)
val NetLandRed = Color(0xFFE55353)
val NetLandRedLight = Color(0xFFFFF0F0)
val NetLandPink = Color(0xFFE83E8C)
val NetLandPinkLight = Color(0xFFFDE8F0)
val NetLandYellow = Color(0xFFFFC83D)
val NetLandBgLight = Color(0xFFF8F8FC)
val NetLandWhite = Color(0xFFFFFFFF)
val NetLandText = Color(0xFF20202A)
val NetLandTextSecondary = Color(0xFF6F7180)
val NetLandTextMuted = Color(0xFF999BA8)
val NetLandBorder = Color(0xFFECECF3)

// Dark Theme Colors
val NetLandBgDark = Color(0xFF0F0F17)
val NetLandCardDark = Color(0xFF1A1A2E)
val NetLandTextDark = Color(0xFFF1F1F6)
val NetLandTextSecondaryDark = Color(0xFFA1A1B5)
val NetLandBorderDark = Color(0xFF2A2A40)
