// ============================================
// api-config.js - اتصال به Cloudflare Worker
// ============================================

const API_BASE_URL = 'https://net-land-api.zz4591757.workers.dev';

// کلید ذخیره‌سازی کش جشنواره‌ها در localStorage
const FESTIVALS_CACHE_KEY = 'netland_festivals_offline_cache';

function getCachedFestivals() {
  try {
    const raw = localStorage.getItem(FESTIVALS_CACHE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch (e) {
    console.warn('⚠️ خطا در خواندن کش جشنواره‌ها:', e);
    return [];
  }
}

function saveCachedFestivals(festivals) {
  if (Array.isArray(festivals) && festivals.length > 0) {
    try {
      localStorage.setItem(FESTIVALS_CACHE_KEY, JSON.stringify(festivals));
      console.log('💾 جشنواره‌ها در حافظه کش محلی ذخیره شدند:', festivals.length);
    } catch (e) {
      console.warn('⚠️ خطا در ذخیره کش جشنواره‌ها:', e);
    }
  }
}

async function getFestivals() {
  try {
    // تلاش برای دریافت مستقیم از سرور کلادفلر
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 7000);
    const response = await fetch(`${API_BASE_URL}/api/festivals`, {
      signal: controller.signal
    });
    clearTimeout(timeoutId);

    if (response && response.ok) {
      const data = await response.json();
      
      if (data && data.documents && Array.isArray(data.documents)) {
        const docs = data.documents.map(doc => {
          const fields = doc.fields || {};
          return {
            id: doc.name ? doc.name.split('/').pop() : '',
            title: fields.title?.stringValue || 'بدون عنوان',
            badge: fields.badge?.stringValue || 'ویژه',
            description: fields.description?.stringValue || '',
            type: fields.type?.stringValue || 'charge',
            icon: fields.icon?.stringValue || 'purple',
            status: fields.status?.stringValue || 'active',
            meta: fields.meta?.stringValue || fields.endDate?.stringValue || '',
            information: fields.information?.stringValue || '',
            link: fields.link?.stringValue || '#',
            referralCode: fields.referralCode?.stringValue || '',
            image: fields.image?.stringValue || '',
            durationType: fields.durationType?.stringValue || '',
            createdAt: fields.createdAt?.timestampValue || null,
            endDate: fields.endDate?.stringValue || ''
          };
        });

        if (docs.length > 0) {
          saveCachedFestivals(docs);
        }

        if (typeof Android !== 'undefined' && Android.checkUpdates) {
          try { Android.checkUpdates(); } catch (e) {}
        }
        return docs;
      }
    }
    
    // اگر پاسخ سرور معتبر نبود یا خطای اچ‌تی‌تی‌پی داشت، از آخرین کش استفاده می‌شود
    console.warn('⚠️ پاسخ نامعتبر از سرور، استفاده از کش ذخیره شده');
    const cached = getCachedFestivals();
    if (cached.length > 0) return cached;
    return [];

  } catch (error) {
    console.warn('⚠️ خطا یا عدم دسترسی به سرور، بازیابی جشنواره‌ها از آخرین کش:', error);
    const cached = getCachedFestivals();
    if (cached.length > 0) {
      console.log('✅ جشنواره‌ها با موفقیت از آخرین کش بارگذاری شدند:', cached.length);
      return cached;
    }
    return [];
  }
}

// ============================================
// دریافت جزئیات یک جشنواره با ID (برای festival-detail.html)
// ============================================
async function getFestivalById(id) {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 7000);
    const response = await fetch(`${API_BASE_URL}/api/festival/${id}`, {
      signal: controller.signal
    });
    clearTimeout(timeoutId);

    if (response && response.ok) {
      const data = await response.json();
      if (data && data.fields) {
        const fields = data.fields;
        return {
          id: data.name ? data.name.split('/').pop() : id,
          title: fields.title?.stringValue || 'بدون عنوان',
          badge: fields.badge?.stringValue || 'ویژه',
          description: fields.description?.stringValue || '',
          type: fields.type?.stringValue || 'charge',
          icon: fields.icon?.stringValue || 'purple',
          status: fields.status?.stringValue || 'active',
          meta: fields.meta?.stringValue || fields.endDate?.stringValue || '',
          information: fields.information?.stringValue || '',
          link: fields.link?.stringValue || '#',
          referralCode: fields.referralCode?.stringValue || '',
          image: fields.image?.stringValue || '',
          durationType: fields.durationType?.stringValue || '',
          endDate: fields.endDate?.stringValue || '',
          joinUrl: fields.joinUrl?.stringValue || fields.link?.stringValue || '',
          createdAt: fields.createdAt?.timestampValue || null
        };
      }
    }
    
    // در صورت قطعی ارتباط با سرور، جشنواره از کش محلی پیدا می‌شود
    const cached = getCachedFestivals();
    const found = cached.find(f => f.id === id);
    if (found) {
      console.log('✅ جزئیات جشنواره از کش محلی بازیابی شد:', found.title);
      return found;
    }
    return null;

  } catch (error) {
    console.warn('⚠️ خطا در دریافت جزئیات جشنواره از سرور، جستجو در کش محلی:', error);
    const cached = getCachedFestivals();
    const found = cached.find(f => f.id === id);
    if (found) {
      console.log('✅ جزئیات جشنواره از کش محلی بازیابی شد:', found.title);
      return found;
    }
    return null;
  }
}

// ============================================
// پشتیبانی (Support) - برای support.html
// ============================================

function mapFirestoreDocToSupportMsg(doc, fallbackUserId) {
  const fields = doc.fields || {};
  const docId = doc.name ? doc.name.split('/').pop() : '';
  const msgUserId = fields.userId?.stringValue || fallbackUserId || '';
  const username = fields.username?.stringValue || '';
  const message = fields.message?.stringValue || '';
  const reply = fields.reply?.stringValue || null;
  const replyText = fields.replyText?.stringValue || null;
  const repliedBy = fields.repliedBy?.stringValue || null;
  const repliedAt = fields.repliedAt?.timestampValue || null;
  const createdAt = fields.createdAt?.timestampValue || null;

  const isAdmin = fields.isAdmin?.booleanValue === true ||
                  fields.sender?.stringValue === 'admin' ||
                  fields.senderType?.stringValue === 'admin' ||
                  fields.role?.stringValue === 'admin' ||
                  repliedBy === 'admin';

  return {
    id: docId,
    userId: msgUserId,
    username: username,
    message: message,
    isAdmin: isAdmin,
    reply: reply,
    replyText: replyText,
    repliedBy: repliedBy,
    repliedAt: repliedAt,
    createdAt: createdAt
  };
}

// ============================================
// دریافت پیام‌های کاربر و پاسخ‌های ادمین
// ============================================
async function getUserSupportMessages(userId) {
  if (!userId) return [];
  const cleanUserId = String(userId).replace(/"/g, '').trim();
  try {
    let docs = [];

    // ۰. تلاش اولویت اول (فوق‌العاده سریع و مطمئن در اندروید بدون مشکل CORS یا فایروال):
    if (window.Android && typeof window.Android.fetchUserSupportMessages === 'function') {
      try {
        const nativeRaw = window.Android.fetchUserSupportMessages(cleanUserId);
        if (nativeRaw && nativeRaw.length > 5) {
          const parsed = JSON.parse(nativeRaw);
          if (parsed && Array.isArray(parsed.documents) && parsed.documents.length > 0) {
            docs = parsed.documents;
          }
        }
      } catch (nativeErr) {
        console.warn('⚠️ خطا در دریافت پیام‌ها از پل نیتیو اندروید:', nativeErr);
      }
    }

    // ۱. تلاش دوم: فراخوانی مستقیم اندپوینت اختصاصی کاربر در ورکر با هدر X-User-Id
    if (!docs || docs.length === 0) {
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 6000);
        const response = await fetch(`${API_BASE_URL}/api/support-user/${encodeURIComponent(cleanUserId)}`, {
          headers: {
            'X-User-Id': cleanUserId,
            'Accept': 'application/json'
          },
          signal: controller.signal
        });
        clearTimeout(timeoutId);

        if (response && response.ok) {
          const data = await response.json();
          if (data && data.documents && Array.isArray(data.documents)) {
            docs = data.documents;
          }
        }
      } catch (workerErr) {
        console.warn('⚠️ خطا در دریافت پیام‌ها از اندپوینت ورکر:', workerErr);
      }
    }

    // ۲. تلاش سوم (پشتیبان مستقیم Firestore REST): کوئری ساختاریافته runQuery برای همان کاربر
    if (!docs || docs.length === 0) {
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 7000);
        const fsResp = await fetch(
          'https://firestore.googleapis.com/v1/projects/net-land-web/databases/(default)/documents:runQuery',
          {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json'
            },
            body: JSON.stringify({
              structuredQuery: {
                from: [{ collectionId: 'support_messages' }],
                where: {
                  fieldFilter: {
                    field: { fieldPath: 'userId' },
                    op: 'EQUAL',
                    value: { stringValue: cleanUserId }
                  }
                }
              }
            }),
            signal: controller.signal
          }
        );
        clearTimeout(timeoutId);

        if (fsResp && fsResp.ok) {
          const fsResults = await fsResp.json();
          if (Array.isArray(fsResults)) {
            docs = fsResults.map(item => item.document).filter(Boolean);
          }
        }
      } catch (fsErr) {
        console.warn('⚠️ خطا در دریافت پیام‌ها از Firestore runQuery:', fsErr);
      }
    }

    if (!Array.isArray(docs)) return [];

    const result = [];
    docs.forEach(doc => {
      const item = mapFirestoreDocToSupportMsg(doc, userId);
      // پیام کاربر
      if (item.message && !item.isAdmin) {
        result.push({
          id: item.id,
          userId: item.userId,
          username: item.username,
          message: item.message,
          isAdmin: false,
          createdAt: item.createdAt
        });
      }
      // پیام مستقیم ادمین
      if (item.isAdmin && item.message) {
        result.push({
          id: item.id,
          userId: item.userId,
          username: 'پشتیبانی نت لند',
          message: item.message,
          isAdmin: true,
          createdAt: item.createdAt || item.repliedAt
        });
      }
      // پاسخ ثبت شده در فیلد reply/replyText
      const adminReply = item.reply || item.replyText;
      if (adminReply && (!item.isAdmin || adminReply !== item.message)) {
        result.push({
          id: item.id + '_reply',
          userId: item.userId,
          username: 'پشتیبانی نت لند',
          message: adminReply,
          isAdmin: true,
          createdAt: item.repliedAt || item.createdAt
        });
      }
    });

    return result;
  } catch (error) {
    console.warn('❌ خطا در getUserSupportMessages:', error);
    return [];
  }
}

// ============================================
// ارسال پیام پشتیبانی توسط کاربر
// ============================================
async function sendSupportMessage(userId, username, message, isAdmin = false) {
  try {
    const payload = {
      userId,
      username: username || 'کاربر مهمان',
      message,
      isAdmin: isAdmin || false,
      repliedBy: isAdmin ? 'admin' : null,
      sender: isAdmin ? 'admin' : 'user',
      senderType: isAdmin ? 'admin' : 'user',
      role: isAdmin ? 'admin' : 'user'
    };

    let sent = false;
    // ارسال به ورکر با هدر X-User-Id
    try {
      const response = await fetch(`${API_BASE_URL}/api/support`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-User-Id': userId
        },
        body: JSON.stringify(payload)
      });
      if (response && response.ok) {
        sent = true;
      }
    } catch (e) {
      console.warn('⚠️ خطا در ارسال پیام به ورکر:', e);
    }

    // در صورت عدم موفقیت ورکر، درج مستقیم در دیتابیس Firestore REST
    if (!sent) {
      try {
        const fsPayload = {
          fields: {
            userId: { stringValue: userId },
            username: { stringValue: username || 'کاربر مهمان' },
            message: { stringValue: message },
            isAdmin: { booleanValue: isAdmin },
            sender: { stringValue: isAdmin ? 'admin' : 'user' },
            senderType: { stringValue: isAdmin ? 'admin' : 'user' },
            role: { stringValue: isAdmin ? 'admin' : 'user' },
            repliedBy: { stringValue: isAdmin ? 'admin' : '' },
            createdAt: { timestampValue: new Date().toISOString() }
          }
        };
        await fetch(
          'https://firestore.googleapis.com/v1/projects/net-land-web/databases/(default)/documents/support_messages',
          {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(fsPayload)
          }
        );
      } catch (fsErr) {
        console.warn('⚠️ خطا در ارسال به Firestore REST:', fsErr);
      }
    }

    return { success: true };
  } catch (error) {
    console.warn('❌ خطا در ارسال پیام پشتیبانی:', error);
    return { success: false, error: error.message };
  }
}

// دریافت کلیه پیام‌ها (سازگاری عمومی)
async function getSupportMessages() {
  return await getUserSupportMessages(getUserId());
}

async function getAllSupportMessages() {
  return await getSupportMessages();
}

async function sendAdminReply(userId, userName, message) {
  return await sendSupportMessage(userId, userName, message, true);
}

// ============================================
// توابع کمکی
// ============================================

function getUserId() {
  let id = localStorage.getItem('netland_user_id');
  if (id) {
    id = String(id).replace(/"/g, '').trim();
  }
  if ((!id || id === 'null') && window.Android && typeof window.Android.getSavedUserId === 'function') {
    try {
      const nativeId = window.Android.getSavedUserId();
      if (nativeId && nativeId.length > 3) {
        id = String(nativeId).replace(/"/g, '').trim();
        localStorage.setItem('netland_user_id', id);
      }
    } catch (_) {}
  }
  if (!id || id === 'null') {
    id = 'user_' + Date.now() + '_' + Math.random().toString(36).substr(2, 6);
    localStorage.setItem('netland_user_id', id);
  }
  if (window.Android && typeof window.Android.onUserIdentified === 'function') {
    try { window.Android.onUserIdentified(id); } catch (_) {}
  }
  return id;
}


function getUserName() {
  let name = localStorage.getItem('netland_username');
  if (!name) {
    name = 'کاربر مهمان';
  }
  return name;
}