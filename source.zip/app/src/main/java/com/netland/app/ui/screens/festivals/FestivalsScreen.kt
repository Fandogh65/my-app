package com.netland.app.ui.screens.festivals

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.netland.app.data.model.Festival
import com.netland.app.data.repository.FestivalRepository
import com.netland.app.ui.navigation.Screen
import com.netland.app.ui.screens.home.FestivalCardItem
import com.netland.app.ui.theme.NetLandPrimary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FestivalsScreen(navController: NavController) {
    val repository = remember { FestivalRepository() }
    var allFestivals by remember { mutableStateOf<List<Festival>>(emptyList()) }
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("all") }
    var isLoading by remember { mutableStateOf(true) }

    val categories = listOf(
        "all" to "همه",
        "charge" to "شارژ رایگان",
        "internet" to "بسته اینترنت",
        "combo" to "ترکیبی",
        "special" to "ویژه"
    )

    LaunchedEffect(Unit) {
        allFestivals = repository.getFestivals()
        isLoading = false
    }

    val filteredFestivals = allFestivals.filter { festival ->
        val matchesCategory = if (selectedCategory == "all") true else festival.type == selectedCategory
        val matchesSearch = searchQuery.isEmpty() ||
                festival.title.contains(searchQuery, ignoreCase = true) ||
                festival.description.contains(searchQuery, ignoreCase = true)
        matchesCategory && matchesSearch
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Page Title
        Text(
            text = "همه جشنواره‌ها",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 20.dp, bottom = 10.dp),
            color = MaterialTheme.colorScheme.onBackground
        )

        // Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("جستجو در جشنواره‌ها...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { searchQuery = "" }) {
                        Icon(Icons.Default.Clear, contentDescription = "پاک کردن")
                    }
                }
            },
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 6.dp),
            singleLine = true
        )

        // Categories Row
        LazyRow(
            modifier = Modifier.padding(vertical = 8.dp),
            contentPadding = PaddingValues(horizontal = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(categories) { (key, label) ->
                val isSelected = selectedCategory == key
                FilterChip(
                    selected = isSelected,
                    onClick = { selectedCategory = key },
                    label = { Text(label) },
                    shape = RoundedCornerShape(14.dp),
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = NetLandPrimary,
                        selectedLabelColor = Color.White
                    )
                )
            }
        }

        // Results count
        Text(
            text = "${filteredFestivals.size} مورد یافت شد",
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
            modifier = Modifier.padding(horizontal = 22.dp, vertical = 4.dp)
        )

        if (isLoading) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = NetLandPrimary)
            }
        } else if (filteredFestivals.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(30.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "جشنواره‌ای با این مشخصات یافت نشد.",
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 20.dp)
            ) {
                items(filteredFestivals) { festival ->
                    FestivalCardItem(
                        festival = festival,
                        onClick = {
                            navController.navigate(Screen.FestivalDetail.createRoute(festival.id))
                        }
                    )
                }
            }
        }
    }
}
