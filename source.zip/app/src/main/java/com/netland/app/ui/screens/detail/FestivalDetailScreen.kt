package com.netland.app.ui.screens.detail

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.netland.app.data.model.Festival
import com.netland.app.data.repository.FestivalRepository
import com.netland.app.ui.theme.*

@Composable
fun FestivalDetailScreen(
    festivalId: String,
    navController: NavController
) {
    val context = LocalContext.current
    val repository = remember { FestivalRepository() }
    var festival by remember { mutableStateOf<Festival?>(null) }
    var isLoading by remember { mutableStateOf(true) }

    LaunchedEffect(festivalId) {
        val list = repository.getFestivals()
        festival = list.find { it.id == festivalId }
        isLoading = false
    }

    if (isLoading) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = NetLandPrimary)
        }
        return
    }

    val item = festival ?: run {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("جشنواره پیدا نشد")
        }
        return
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Detail Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { navController.popBackStack() }) {
                Icon(Icons.Default.ArrowForward, contentDescription = "بازگشت")
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = item.title,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1
            )
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
        ) {
            // Optional Header Image
            if (item.image.isNotEmpty()) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .padding(vertical = 8.dp),
                    shape = RoundedCornerShape(22.dp)
                ) {
                    AsyncImage(
                        model = item.image,
                        contentDescription = item.title,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                }
            }

            // Duration Box
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Schedule, contentDescription = null, tint = NetLandBlue)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("مدت زمان و اعتبار", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = item.meta.ifEmpty { item.endDate.ifEmpty { "مهلت محدود" } },
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            // Information Box
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Info, contentDescription = null, tint = NetLandGreen)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("توضیحات و راهنما", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = item.information.ifEmpty { item.description.ifEmpty { "توضیحاتی برای این جشنواره ثبت نشده است." } },
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurface,
                        lineHeight = 24.sp
                    )
                }
            }

            // Referral Code Box
            if (item.referralCode.isNotEmpty() && item.referralCode != "-") {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = NetLandOrangeLight)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CardGiftcard, contentDescription = null, tint = NetLandOrange)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("کد معرف یا هدیه", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = NetLandOrange)
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = item.referralCode,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = NetLandText
                            )
                            Button(
                                onClick = {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    val clip = ClipData.newPlainText("Referral", item.referralCode)
                                    clipboard.setPrimaryClip(clip)
                                    Toast.makeText(context, "کد معرف کپی شد!", Toast.LENGTH_SHORT).show()
                                },
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = NetLandOrange)
                            ) {
                                Text("کپی کد", color = Color.White)
                            }
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Action Button
        val joinLink = item.joinUrl.ifEmpty { item.link }
        Button(
            onClick = {
                if (joinLink.isNotEmpty() && joinLink != "#") {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(joinLink))
                    context.startActivity(intent)
                } else {
                    Toast.makeText(context, "لینک معتبری برای این جشنواره موجود نیست", Toast.LENGTH_SHORT).show()
                }
            },
            shape = RoundedCornerShape(18.dp),
            colors = ButtonDefaults.buttonColors(containerColor = NetLandPrimary),
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
                .height(54.dp)
        ) {
            Text("ورود و شرکت در جشنواره", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Spacer(modifier = Modifier.width(8.dp))
            Icon(Icons.Default.OpenInNew, contentDescription = null, tint = Color.White)
        }
    }
}
