package com.netland.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

private val DarkColorScheme = darkColorScheme(
    primary = NetLandPrimary2,
    secondary = NetLandBlue,
    tertiary = NetLandGreen,
    background = NetLandBgDark,
    surface = NetLandCardDark,
    onPrimary = NetLandWhite,
    onBackground = NetLandTextDark,
    onSurface = NetLandTextDark
)

private val LightColorScheme = lightColorScheme(
    primary = NetLandPrimary,
    secondary = NetLandBlue,
    tertiary = NetLandGreen,
    background = NetLandBgLight,
    surface = NetLandWhite,
    onPrimary = NetLandWhite,
    onBackground = NetLandText,
    onSurface = NetLandText
)

@Composable
fun NetLandTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    // Enforce RTL Layout Direction for standard Persian experience
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            colorScheme = colorScheme,
            content = content
        )
    }
}
