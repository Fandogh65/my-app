package com.netland.app.ui.navigation

sealed class Screen(val route: String, val title: String) {
    object Home : Screen("home", "خانه")
    object Festivals : Screen("festivals", "جشنواره‌ها")
    object Favorites : Screen("favorites", "نشان‌شده‌ها")
    object Notifications : Screen("notifications", "اعلان‌ها")
    object Support : Screen("support", "پشتیبانی")
    object Faq : Screen("faq", "سوالات متداول")
    object FestivalDetail : Screen("festival_detail/{festivalId}", "جزئیات جشنواره") {
        fun createRoute(festivalId: String) = "festival_detail/$festivalId"
    }
}
