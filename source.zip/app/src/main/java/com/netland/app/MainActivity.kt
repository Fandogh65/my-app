package com.netland.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.webkit.*
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.ProgressBar
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import com.netland.app.notification.NotificationHelper
import kotlinx.coroutines.*

class MainActivity : ComponentActivity() {

    private lateinit var webView: WebView
    private lateinit var progressBar: ProgressBar
    private lateinit var splashView: ImageView
    private var syncJob: Job? = null
    private var isDeniedDialogShowing = false
    private var isSplashDismissed = false

    // لانچر دریافت دسترسی اعلان در اندروید ۱۳ به بالا (Android 13+ POST_NOTIFICATIONS)
    private val requestNotificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
            if (isGranted) {
                onNotificationPermissionGranted()
            } else {
                onNotificationPermissionDenied()
            }
        }

    // لانچر برای بازگشت از صفحه تنظیمات برنامه (در صورت انتخاب کاربر)
    private val appSettingsLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            checkAndEnforceNotificationPermission()
        }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val rootLayout = FrameLayout(this)

        webView = WebView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )

            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                allowFileAccess = true
                allowContentAccess = true
                allowFileAccessFromFileURLs = true
                allowUniversalAccessFromFileURLs = true
                useWideViewPort = true
                loadWithOverviewMode = true
                mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                cacheMode = WebSettings.LOAD_DEFAULT
                setSupportZoom(false)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    safeBrowsingEnabled = false
                }
            }

            val cookieManager = CookieManager.getInstance()
            cookieManager.setAcceptCookie(true)
            cookieManager.setAcceptThirdPartyCookies(this, true)

            // پل ارتباطی جاوااسکریپت برای دریافت آپدیت‌ها و نوتیفیکیشن
            addJavascriptInterface(WebAppInterface(this@MainActivity, this), "Android")

            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val url = request?.url?.toString() ?: return false

                    // باز کردن لینک‌های خارجی (اپراتورها، بازار، مایکت و...) در مرورگر اصلی
                    if (url.startsWith("tel:") || url.startsWith("mailto:") || url.startsWith("sms:") ||
                        url.startsWith("tg:") || url.startsWith("whatsapp:") || url.startsWith("intent:") ||
                        url.contains("myket.ir") || url.contains("cafebazaar.ir") || url.contains("bazaar://") ||
                        url.contains("zarafza.com") || url.contains("tabdeal.org") || url.contains("wallgold.ir") ||
                        url.contains("saraf.app") || url.contains("talasea.ir") || url.contains("tala724.ir") ||
                        url.contains("zarpin.com") || url.contains("tlyn.ir") || url.contains("melligold.com") ||
                        url.contains("boomobana.com")
                    ) {
                        try {
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                            startActivity(intent)
                            return true
                        } catch (_: Exception) {
                        }
                    }

                    return false
                }

                override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                    super.onPageStarted(view, url, favicon)
                    progressBar.visibility = View.VISIBLE
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    progressBar.visibility = View.GONE

                    // مخفی کردن اسپلش اسکرین پس از بارگذاری کامل صفحه
                    dismissSplash()

                    // هماهنگ‌سازی شناسه کاربر از لوکال استوریج وب‌ویو برای بررسی نوتیفیکیشن‌های پشتیبانی
                    view?.evaluateJavascript(
                        "(function() { try { return localStorage.getItem('netland_user_id') || ''; } catch(e){ return ''; } })()"
                    ) { result ->
                        val cleanId = result?.replace("\"", "")?.trim()
                        if (!cleanId.isNullOrEmpty() && cleanId != "null") {
                            NotificationHelper.saveUserId(this@MainActivity, cleanId)
                        }
                    }
                }

                override fun onReceivedError(
                    view: WebView?,
                    request: WebResourceRequest?,
                    error: WebResourceError?
                ) {
                    super.onReceivedError(view, request, error)
                    if (request?.isForMainFrame == true) {
                        val failingUrl = request.url?.toString() ?: ""
                        if (!failingUrl.startsWith("file:///android_asset/")) {
                            view?.loadUrl("file:///android_asset/netland/index.html")
                        }
                    }
                    dismissSplash()
                }

                override fun onReceivedSslError(
                    view: WebView?,
                    handler: SslErrorHandler?,
                    error: android.net.http.SslError?
                ) {
                    // در نسخه Release جهت اطمینان از عدم مسدود شدن درخواست‌های امن درون وب‌ویو
                    handler?.proceed()
                }
            }

            webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(view: WebView?, newProgress: Int) {
                    progressBar.progress = newProgress
                    if (newProgress >= 100) {
                        progressBar.visibility = View.GONE
                        dismissSplash()
                    }
                }

                override fun onConsoleMessage(consoleMessage: ConsoleMessage?): Boolean {
                    return true
                }
            }
        }

        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                8
            )
            isIndeterminate = false
            max = 100
            visibility = View.GONE
        }

        // نمای اسپلش اسکرین با تصویر ارسالی کاربر
        splashView = ImageView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
            scaleType = ImageView.ScaleType.CENTER_CROP
            setImageResource(R.drawable.splash_netland)
            visibility = View.VISIBLE
        }

        rootLayout.addView(webView)
        rootLayout.addView(progressBar)
        rootLayout.addView(splashView)
        setContentView(rootLayout)

        // تایم‌اوت ایمن برای محو شدن اسپلش اسکرین (حداکثر ۱.۸ ثانیه برای نمایش زیبا و لود شدن وب‌ویو)
        CoroutineScope(Dispatchers.Main).launch {
            delay(1800)
            dismissSplash()
        }

        // مدیریت دکمه بازگشت گوشی
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    finish()
                }
            }
        })

        // بررسی و اجباری بودن دسترسی نوتیفیکیشن در هر بار ورود به برنامه
        checkAndEnforceNotificationPermission()
    }

    private fun dismissSplash() {
        if (!isSplashDismissed) {
            isSplashDismissed = true
            splashView.animate()
                .alpha(0f)
                .setDuration(350)
                .withEndAction {
                    splashView.visibility = View.GONE
                }
                .start()
        }
    }

    /**
     * بررسی دسترسی نوتیفیکیشن:
     * هر بار که کاربر اپلیکیشن را باز می‌کند:
     * ۱. اگر قبلاً مجوز داده شده باشد، برنامه مستقیماً بارگذاری می‌شود.
     * ۲. اگر مجوز داده نشده باشد، بلافاصله دیالوگ سیستمی درخواست مجوز اعلان باز می‌شود.
     * ۳. اگر در تنظیمات گوشی توسط کاربر رد قطعی (Don't ask again) شده باشد، هدایت به تنظیمات برای دادن مجوز نمایش می‌یابد.
     */
    private fun checkAndEnforceNotificationPermission() {
        NotificationHelper.createNotificationChannel(this)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val permissionStatus = ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            )

            if (permissionStatus == PackageManager.PERMISSION_GRANTED) {
                onNotificationPermissionGranted()
            } else {
                // اگر سیستم اجازه نمایش دیالوگ استاندارد را بدهد، آن را باز می‌کنیم
                if (shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS) || !isPermissionPermanentlyDenied()) {
                    requestNotificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                } else {
                    // در حالتی که دسترسی قبلاً بلاک شده است، پنجره راهنمای باز کردن تنظیمات را نشان می‌دهیم
                    showSettingsRedirectDialog()
                }
            }
        } else {
            // در اندرویدهای ۱۲ و پایین‌تر اعلان‌ها پیش‌فرض فعال هستند
            onNotificationPermissionGranted()
        }
    }

    private fun isPermissionPermanentlyDenied(): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val isGranted = ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            return !isGranted && !shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS)
        }
        return false
    }

    private fun onNotificationPermissionGranted() {
        isDeniedDialogShowing = false
        NotificationHelper.createNotificationChannel(this)

        val targetUrl = intent?.getStringExtra("target_url")
        if (!targetUrl.isNullOrEmpty()) {
            webView.loadUrl(targetUrl)
        } else {
            if (webView.url == null) {
                webView.loadUrl("file:///android_asset/netland/index.html")
            }
        }

        triggerInstantCheck()
        startPeriodicBackendCheck()
    }

    /**
     * وقتی کاربر مجوز را در دیالوگ سیستم رد می‌کند:
     * به او هشدار داده شده و با کلیک روی خروج از برنامه خارج می‌شود تا دفعه بعد که برنامه را باز کرد
     * مجدداً پنجره درخواست دسترسی از او پرسیده شود.
     */
    private fun onNotificationPermissionDenied() {
        if (isDeniedDialogShowing || isFinishing) return
        isDeniedDialogShowing = true

        AlertDialog.Builder(this)
            .setTitle("نیاز به تایید اعلان‌ها")
            .setMessage("برای ورود به نت لند و دریافت فوری جدیدترین جشنواره‌ها، هدایا و پاسخ پشتیبانی، اجازه ارسال اعلان الزامی است.\n\nبه دلیل عدم تایید مجوز، برنامه بسته می‌شود. با باز کردن مجدد برنامه، می‌توانید مجوز را تایید کنید.")
            .setCancelable(false)
            .setPositiveButton("بستن برنامه") { _, _ ->
                isDeniedDialogShowing = false
                finishAffinity()
            }
            .setNegativeButton("تلاش مجدد") { _, _ ->
                isDeniedDialogShowing = false
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    if (shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS)) {
                        requestNotificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    } else {
                        showSettingsRedirectDialog()
                    }
                }
            }
            .show()
    }

    /**
     * در حالتی که دسترسی رد شده و دیالوگ سیستمی نمایش داده نمی‌شود، کاربر را به تنظیمات برنامه هدایت می‌کند.
     */
    private fun showSettingsRedirectDialog() {
        if (isDeniedDialogShowing || isFinishing) return
        isDeniedDialogShowing = true

        AlertDialog.Builder(this)
            .setTitle("فعال‌سازی اعلان از تنظیمات")
            .setMessage("مجوز ارسال اعلان برای نت لند غیرفعال است. جهت اطلاع از طرح ها و جشنواره های جدید  نت لند، لطفاً در بخش تنظیمات، اجازه ارسال اعلان (Notifications) را فعال کنید.")
            .setCancelable(false)
            .setPositiveButton("رفتن به تنظیمات") { _, _ ->
                isDeniedDialogShowing = false
                try {
                    val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                        putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
                    }
                    appSettingsLauncher.launch(intent)
                } catch (_: Exception) {
                    try {
                        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                            data = Uri.fromParts("package", packageName, null)
                        }
                        appSettingsLauncher.launch(intent)
                    } catch (_: Exception) {
                        finishAffinity()
                    }
                }
            }
            .setNegativeButton("خروج") { _, _ ->
                isDeniedDialogShowing = false
                finishAffinity()
            }
            .show()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        val targetUrl = intent.getStringExtra("target_url")
        if (!targetUrl.isNullOrEmpty()) {
            webView.loadUrl(targetUrl)
        }
    }

    override fun onResume() {
        super.onResume()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val permissionStatus = ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            )
            if (permissionStatus != PackageManager.PERMISSION_GRANTED) {
                if (!isDeniedDialogShowing) {
                    checkAndEnforceNotificationPermission()
                }
                return
            }
        }
        triggerInstantCheck()
        startPeriodicBackendCheck()
    }

    override fun onDestroy() {
        super.onDestroy()
        syncJob?.cancel()
    }

    private fun triggerInstantCheck() {
        CoroutineScope(Dispatchers.IO).launch {
            NotificationHelper.checkBackendUpdates(this@MainActivity)
        }
    }

    private fun startPeriodicBackendCheck() {
        syncJob?.cancel()
        syncJob = CoroutineScope(Dispatchers.IO).launch {
            while (isActive) {
                NotificationHelper.checkBackendUpdates(this@MainActivity)
                delay(20000)
            }
        }
    }

    class WebAppInterface(private val activity: Activity, private val webView: WebView) {
        @JavascriptInterface
        fun checkUpdates() {
            CoroutineScope(Dispatchers.IO).launch {
                NotificationHelper.checkBackendUpdates(activity)
            }
        }

        @JavascriptInterface
        fun onUserIdentified(userId: String) {
            if (userId.isNotBlank()) {
                NotificationHelper.saveUserId(activity, userId)
                CoroutineScope(Dispatchers.IO).launch {
                    NotificationHelper.checkBackendUpdates(activity)
                }
            }
        }

        @JavascriptInterface
        fun getSavedUserId(): String {
            return NotificationHelper.getSavedUserId(activity) ?: ""
        }

        @JavascriptInterface
        fun fetchUserSupportMessages(userId: String): String {
            return try {
                NotificationHelper.fetchSupportMessagesForUser(userId) ?: ""
            } catch (_: Exception) {
                ""
            }
        }
    }
}

