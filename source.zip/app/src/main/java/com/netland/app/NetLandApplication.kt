package com.netland.app

import android.app.Application

class NetLandApplication : Application() {

    override fun onCreate() {
        super.onCreate()

        // پاکسازی فایل‌های معیوب یا بدون امضای variations_seed کرومیوم در صورت وجود
        try {
            val webViewDir = java.io.File(dataDir, "app_webview")
            if (webViewDir.exists()) {
                val seed = java.io.File(webViewDir, "variations_seed")
                if (seed.exists() && seed.length() == 0L) {
                    seed.delete()
                }
                val seedNew = java.io.File(webViewDir, "variations_seed_new")
                if (seedNew.exists() && seedNew.length() == 0L) {
                    seedNew.delete()
                }
            }
        } catch (_: Throwable) {
        }
    }
}
